Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task 8: Error Handling
... try:
...     num1 = float(input("Enter the first number: "))
...     num2 = float(input("Enter the second number: "))
...     result = num1 / num2
...     print(f"The result of division is: {result}")
... except ZeroDivisionError:
...     print("Error: Cannot divide by zero.")
... except ValueError:
