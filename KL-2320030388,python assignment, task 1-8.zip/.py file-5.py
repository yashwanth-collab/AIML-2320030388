Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task 5: Functions
... def calculate_area(shape, dimension1, dimension2=None):
...     if shape == "circle":
...         return 3.14159 * (dimension1 ** 2)
...     elif shape == "rectangle":
...         return dimension1 * dimension2
...     elif shape == "triangle":
...         return 0.5 * dimension1 * dimension2
...     else:
...         return "Invalid shape"
... 
... print("Area of circle with radius 5:", calculate_area("circle", 5))
... print("Area of rectangle with length 4 and width 7:", calculate_area("rectangle", 4, 7))
... print("Area of triangle with base 6 and height 8:", calculate_area("triangle", 6, 8))
