Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Task 1: Variables and Data Types
... name = input("Enter your name: ")
... age = int(input("Enter your age: "))
... fav_number = int(input("Enter your favorite number: "))
... 
... greeting = f"Hello, {name}!"
... turn_100_year = 2024 + (100 - age)
... doubled_fav_number = fav_number * 2
... 
... print(greeting)
... print(f"You will turn 100 years old in the year {turn_100_year}.")
