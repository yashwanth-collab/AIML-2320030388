Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task 4: Lists and Dictionaries
... foods = []
... for _ in range(5):
...     food = input("Enter one of your favorite foods: ")
...     foods.append(food)
... 
... print("Your favorite foods list:", foods)
... 
... food_dict = {food: len(food) for food in foods}
... print("Dictionary with food lengths:", food_dict)
