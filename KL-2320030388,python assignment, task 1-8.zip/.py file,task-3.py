Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task 3: Loops
... print("Even numbers between 1 and 50 using for loop:")
... for num in range(2, 51, 2):
...     print(num, end=" ")
... 
... print("\nEven numbers between 1 and 50 using while loop:")
... i = 2
... while i <= 50:
...     print(i, end=" ")
