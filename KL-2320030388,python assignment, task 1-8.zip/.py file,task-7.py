Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task 7: File Handling
... file_name = "data.txt"
... with open(file_name, "w") as file:
...     file.write("Hello, Python!\n")
...     file.write("Learning file handling.\n")
...     file.write("Python is fun!\n")
... 
... with open(file_name, "r") as file:
...     content = file.read()
...     print("File content:")
