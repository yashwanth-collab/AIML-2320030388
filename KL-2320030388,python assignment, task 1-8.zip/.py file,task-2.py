Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task-2
... number = float(input("Enter a number: "))
... 
... if number % 2 == 0:
...     print("The number is even.")
... else:
...     print("The number is odd.")
... 
... if number > 0:
...     print("The number is positive.")
... elif number < 0:
...     print("The number is negative.")
... else:
...     print("The number is zero.")
