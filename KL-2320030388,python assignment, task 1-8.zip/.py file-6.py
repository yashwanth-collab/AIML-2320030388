Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Task 6: String Manipulation
... sentence = input("Enter a sentence: ")
... vowels = "aeiouAEIOU"
... vowel_count = sum(1 for char in sentence if char in vowels)
... 
... print(f"Number of vowels in the sentence: {vowel_count}")
... print("Reversed sentence:", sentence[::-1])
