import tkinter as tk
import requests
import time

# Function to fetch and display weather for the first city
def getWeather(event=None):
    city = textField.get()
    api = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=06c921750b9a82d8f5d1294e1586276f"
    
    json_data = requests.get(api).json()
    condition = json_data['weather'][0]['main']
    temp = int(json_data['main']['temp'] - 273.15)
    min_temp = int(json_data['main']['temp_min'] - 273.15)
    max_temp = int(json_data['main']['temp_max'] - 273.15)
    pressure = json_data['main']['pressure']
    humidity = json_data['main']['humidity']
    wind = json_data['wind']['speed']
    sunrise = time.strftime('%I:%M:%S', time.gmtime(json_data['sys']['sunrise'] - 21600))
    sunset = time.strftime('%I:%M:%S', time.gmtime(json_data['sys']['sunset'] - 21600))
    
    final_info = condition + "\n" + str(temp) + "°C"
    final_data = (
        "\nMin Temp: " + str(min_temp) + "°C" + "\n" +
        "Max Temp: " + str(max_temp) + "°C" + "\n" +
        "Pressure: " + str(pressure) + "\n" +
        "Humidity: " + str(humidity) + "\n" +
        "Wind Speed: " + str(wind) + "\n" +
        "Sunrise: " + sunrise + "\n" +
        "Sunset: " + sunset
    )
    label1.config(text=final_info)
    label2.config(text=final_data)

# Function to fetch and display weather for the second city
def getWeather2(event=None):
    city = textField2.get()
    api = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=06c921750b9a82d8f5d1294e1586276f"
    
    json_data = requests.get(api).json()
    condition = json_data['weather'][0]['main']
    temp = int(json_data['main']['temp'] - 273.15)
    min_temp = int(json_data['main']['temp_min'] - 273.15)
    max_temp = int(json_data['main']['temp_max'] - 273.15)
    pressure = json_data['main']['pressure']
    humidity = json_data['main']['humidity']
    wind = json_data['wind']['speed']
    sunrise = time.strftime('%I:%M:%S', time.gmtime(json_data['sys']['sunrise'] - 21600))
    sunset = time.strftime('%I:%M:%S', time.gmtime(json_data['sys']['sunset'] - 21600))
    
    final_info = condition + "\n" + str(temp) + "°C"
    final_data = (
        "\nMin Temp: " + str(min_temp) + "°C" + "\n" +
        "Max Temp: " + str(max_temp) + "°C" + "\n" +
        "Pressure: " + str(pressure) + "\n" +
        "Humidity: " + str(humidity) + "\n" +
        "Wind Speed: " + str(wind) + "\n" +
        "Sunrise: " + sunrise + "\n" +
        "Sunset: " + sunset
    )
    label3.config(text=final_info)
    label4.config(text=final_data)

# Setting up the main window
canvas = tk.Tk()
canvas.geometry("600x650")
canvas.title("Weather App for Two Cities")
f = ("poppins", 15, "bold")
t = ("poppins", 35, "bold")

# --- First city widgets ---
# Label and entry for the first city
city_label1 = tk.Label(canvas, text="Enter First City:", font=f)
city_label1.pack(pady=5)

textField = tk.Entry(canvas, justify='center', width=20, font=t)
textField.pack(pady=5)
textField.focus()
textField.bind('<Return>', getWeather)

# Labels to display weather data for the first city
label1 = tk.Label(canvas, font=t)
label1.pack()
label2 = tk.Label(canvas, font=f)
label2.pack()

# --- Second city widgets ---
# Label and entry for the second city
city_label2 = tk.Label(canvas, text="Enter Second City:", font=f)
city_label2.pack(pady=20)

textField2 = tk.Entry(canvas, justify='center', width=20, font=t)
textField2.pack(pady=5)
textField2.bind('<Return>', getWeather2)

# Labels to display weather data for the second city
label3 = tk.Label(canvas, font=t)
label3.pack()
label4 = tk.Label(canvas, font=f)
label4.pack()

canvas.mainloop()
