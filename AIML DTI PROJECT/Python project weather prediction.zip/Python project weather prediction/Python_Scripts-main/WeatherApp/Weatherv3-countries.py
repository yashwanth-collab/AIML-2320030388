import tkinter as tk
from tkinter import ttk, messagebox
import requests
import time

# Global API key and URL
API_KEY = "06c921750b9a82d8f5d1294e1586276f"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

class WeatherFrame(ttk.Frame):
    """
    A frame that handles weather fetching and displaying for one country.
    """
    def __init__(self, parent, country_number, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.country_number = country_number
        self.create_widgets()
    
    def create_widgets(self):
        # Instruction label
        instruction = f"Enter Country {self.country_number} (or its capital/major city):"
        self.label_instruction = ttk.Label(self, text=instruction, font=("Poppins", 15, "bold"))
        self.label_instruction.grid(row=0, column=0, columnspan=2, pady=(10, 5), sticky="w")
        
        # Entry widget for country name
        self.entry_country = ttk.Entry(self, width=25, font=("Poppins", 14))
        self.entry_country.grid(row=1, column=0, padx=10, pady=5)
        self.entry_country.bind('<Return>', self.get_weather)
        
        # Button to fetch weather
        self.button_fetch = ttk.Button(self, text="Get Weather", command=self.get_weather)
        self.button_fetch.grid(row=1, column=1, padx=10, pady=5)
        
        # Labels to display weather summary and details
        self.label_summary = ttk.Label(self, font=("Poppins", 20, "bold"), foreground="blue")
        self.label_summary.grid(row=2, column=0, columnspan=2, pady=5)
        
        self.label_details = ttk.Label(self, font=("Poppins", 12))
        self.label_details.grid(row=3, column=0, columnspan=2, pady=5)
        
    def get_weather(self, event=None):
        country = self.entry_country.get().strip()
        if not country:
            messagebox.showerror("Input Error", "Please enter a country or city name.")
            return
        
        url = f"{BASE_URL}?q={country}&appid={API_KEY}"
        
        try:
            response = requests.get(url)
            response.raise_for_status()
            json_data = response.json()
            
            # Parse weather data
            condition = json_data['weather'][0]['main']
            temp = int(json_data['main']['temp'] - 273.15)
            min_temp = int(json_data['main']['temp_min'] - 273.15)
            max_temp = int(json_data['main']['temp_max'] - 273.15)
            pressure = json_data['main']['pressure']
            humidity = json_data['main']['humidity']
            wind = json_data['wind']['speed']
            sunrise = time.strftime('%I:%M:%S', time.gmtime(json_data['sys']['sunrise'] - 21600))
            sunset = time.strftime('%I:%M:%S', time.gmtime(json_data['sys']['sunset'] - 21600))
            
            final_info = f"{condition}\n{temp}°C"
            final_details = (
                f"Min Temp: {min_temp}°C\n"
                f"Max Temp: {max_temp}°C\n"
                f"Pressure: {pressure}\n"
                f"Humidity: {humidity}\n"
                f"Wind Speed: {wind}\n"
                f"Sunrise: {sunrise}\n"
                f"Sunset: {sunset}"
            )
            
            self.label_summary.config(text=final_info)
            self.label_details.config(text=final_details)
        
        except requests.exceptions.HTTPError as http_err:
            messagebox.showerror("HTTP Error", f"HTTP error occurred: {http_err}")
        except Exception as err:
            messagebox.showerror("Error", f"An error occurred: {err}")

class WeatherApp(tk.Tk):
    """
    Main application class that centers the Notebook content.
    """
    def __init__(self):
        super().__init__()
        self.title("Weather App for Three Countries")
        self.geometry("700x800")
        self.configure(bg="lightgray")
        self.create_menu()
        self.create_widgets()
    
    def create_menu(self):
        menu_bar = tk.Menu(self)
        self.config(menu=menu_bar)
        
        file_menu = tk.Menu(menu_bar, tearoff=0)
        file_menu.add_command(label="Exit", command=self.quit)
        menu_bar.add_cascade(label="File", menu=file_menu)
        
        help_menu = tk.Menu(menu_bar, tearoff=0)
        help_menu.add_command(label="About", command=self.show_about)
        menu_bar.add_cascade(label="Help", menu=help_menu)
    
    def show_about(self):
        messagebox.showinfo("About", "Weather App\nVersion 1.0\nFetches weather for three countries using OpenWeatherMap API.")
    
    def create_widgets(self):
        # Configure grid to center content
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Create Notebook (tabbed interface) and place it at the center
        notebook = ttk.Notebook(self)
        notebook.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        
        self.frame1 = WeatherFrame(notebook, country_number=1)
        self.frame2 = WeatherFrame(notebook, country_number=2)
        self.frame3 = WeatherFrame(notebook, country_number=3)
        
        notebook.add(self.frame1, text="Country 1")
        notebook.add(self.frame2, text="Country 2")
        notebook.add(self.frame3, text="Country 3")
        
        # Optional footer
        footer = ttk.Label(self, text="Enter the capital or major city of a country for accurate weather data.", font=("Poppins", 10), background="lightgray")
        footer.grid(row=1, column=0, pady=(0, 10))

if __name__ == "__main__":
    app = WeatherApp()
    app.mainloop()




