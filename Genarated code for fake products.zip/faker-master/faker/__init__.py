from faker.factory import Factory
from faker.generator import Generator
from faker.proxy import Faker

VERSION = "33.3.1"

__all__ = ("Factory", "Generator", "Faker")
